These file were copied and pasted and modified from ssolverutils in StellarSolver
https://github.com/rlancaste/stellarsolver/tree/master/ssolverutils
fileio is re-appended with more methods from Kstars Fitsviewer/fitsdata
(Load from blob, statistics ...)
https://github.com/KDE/kstars/blob/master/kstars/fitsviewer/fitsdata.h


